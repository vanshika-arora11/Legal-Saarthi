import HeroSection from "@/components/hero-section"
import FeaturesSection from "@/components/features-section"
import LegalTopicsGrid from "@/components/legal-topics-grid"
import AIChatbotSection from "@/components/ai-chatbot-section"
import DashboardPreview from "@/components/dashboard-preview"
import LanguageSection from "@/components/language-section"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />
      <FeaturesSection />
      <LegalTopicsGrid />
      <AIChatbotSection />
      <DashboardPreview />
      <LanguageSection />
      <Footer />
    </div>
  )
}
