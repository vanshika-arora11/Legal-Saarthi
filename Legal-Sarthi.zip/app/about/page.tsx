import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-10 px-4 md:px-6">
      <div className="flex flex-col space-y-10">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold tracking-tight">About Legal Saarthi</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Bridging the legal literacy gap—enabling informed decisions and confident legal actions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-8">
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Our Mission</h2>
            <p className="text-muted-foreground">
              Legal Saarthi was founded with a simple yet powerful mission: to democratize legal knowledge and make it
              accessible to everyone in India, regardless of their background, education, or language.
            </p>
            <p className="text-muted-foreground">
              We believe that understanding your legal rights and responsibilities is fundamental to navigating life's
              challenges with confidence and dignity.
            </p>
          </div>
          <div className="space-y-4">
            <h2 className="text-2xl font-bold">Our Vision</h2>
            <p className="text-muted-foreground">
              We envision a society where legal literacy is universal, where every citizen can understand and assert
              their rights, and where justice is truly accessible to all.
            </p>
            <p className="text-muted-foreground">
              Through technology and simplified content, we aim to remove the barriers that have traditionally kept
              legal knowledge in the hands of a few.
            </p>
          </div>
        </div>

        <Card className="bg-primary/5 border-none">
          <CardContent className="p-8">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-center">What We Do</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Simplify Legal Concepts</h3>
                  <p className="text-sm text-muted-foreground">
                    We break down complex legal jargon into simple, understandable language for everyone.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Provide 24/7 AI Assistance</h3>
                  <p className="text-sm text-muted-foreground">
                    Our AI chatbot offers instant, reliable help for your legal questions anytime you need it.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                      <polyline points="14 2 14 8 20 8"></polyline>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Create Ready-to-Use Templates</h3>
                  <p className="text-sm text-muted-foreground">
                    We offer downloadable templates for RTIs, complaints, notices, and more to save you time and effort.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="m4.93 4.93 4.24 4.24"></path>
                      <path d="m14.83 9.17 4.24-4.24"></path>
                      <path d="m14.83 14.83 4.24 4.24"></path>
                      <path d="m9.17 14.83-4.24 4.24"></path>
                      <circle cx="12" cy="12" r="4"></circle>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Support Multiple Languages</h3>
                  <p className="text-sm text-muted-foreground">
                    We eliminate language barriers with support for multiple Indian languages.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Protect Your Rights</h3>
                  <p className="text-sm text-muted-foreground">
                    We empower you with knowledge to protect yourself in situations involving fraud, harassment, or
                    rights violations.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <path d="M18 6H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h13l4-3.5L18 6Z"></path>
                      <path d="M12 13v8"></path>
                      <path d="M12 3v3"></path>
                    </svg>
                  </div>
                  <h3 className="font-semibold">Guide Step-by-Step</h3>
                  <p className="text-sm text-muted-foreground">
                    We provide clear, step-by-step guidance for navigating real-life legal issues.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-8">
          <h2 className="text-2xl font-bold text-center">Our Team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[
              { name: "Priya Sharma", role: "Founder & Legal Expert", avatar: "PS" },
              { name: "Rahul Verma", role: "Technology Lead", avatar: "RV" },
              { name: "Ananya Patel", role: "Content Director", avatar: "AP" },
              { name: "Vikram Singh", role: "AI Research Head", avatar: "VS" },
            ].map((member) => (
              <div key={member.name} className="flex flex-col items-center space-y-2 text-center">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={`/placeholder.svg?height=96&width=96`} alt={member.name} />
                  <AvatarFallback className="text-lg">{member.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{member.name}</h3>
                  <p className="text-sm text-muted-foreground">{member.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-primary/5 rounded-lg p-8 text-center space-y-4">
          <h2 className="text-2xl font-bold">Join Our Mission</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We're always looking for passionate individuals who share our vision of making legal knowledge accessible to
            all. Whether you're a legal expert, content creator, or technology enthusiast, there might be a place for
            you on our team.
          </p>
          <div className="pt-4">
            <a
              href="#"
              className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
