import Link from "next/link"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Building, Users, Shield, User, ShoppingCart, FileSearch, ArrowRight } from "lucide-react"

export default function LegalTopicsGrid() {
  const topics = [
    {
      icon: Building,
      title: "Tenant Rights",
      description: "Learn about rental agreements, eviction laws, and maintenance responsibilities.",
      href: "#tenant-rights",
    },
    {
      icon: Users,
      title: "Employment Laws",
      description: "Understand workplace rights, contracts, harassment policies, and compensation.",
      href: "#employment-laws",
    },
    {
      icon: Shield,
      title: "Cybercrime",
      description: "Protect yourself from online fraud, identity theft, and digital harassment.",
      href: "#cybercrime",
    },
    {
      icon: User,
      title: "Women's Safety",
      description: "Know your legal protections against harassment, domestic violence, and discrimination.",
      href: "#womens-safety",
    },
    {
      icon: ShoppingCart,
      title: "Consumer Protection",
      description: "Learn how to address product defects, service issues, and unfair business practices.",
      href: "#consumer-protection",
    },
    {
      icon: FileSearch,
      title: "Filing FIRs / RTIs",
      description: "Step-by-step guides to file police complaints and right to information requests.",
      href: "#filing-firs-rtis",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24" id="legal-topics">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Explore Legal Help Topics</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Browse through our comprehensive library of legal topics relevant to everyday situations.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
          {topics.map((topic, index) => (
            <Card key={index} className="flex flex-col h-full">
              <CardHeader>
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <topic.icon className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>{topic.title}</CardTitle>
                <CardDescription>{topic.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto pt-4">
                <Button variant="ghost" asChild className="w-full justify-between">
                  <Link href={topic.href}>
                    Learn more <ArrowRight className="h-4 w-4 ml-2" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
