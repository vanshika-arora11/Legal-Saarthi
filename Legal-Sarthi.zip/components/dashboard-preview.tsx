"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { FileText, CheckCircle, AlertCircle, Clock } from "lucide-react"

export default function DashboardPreview() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  if (!isLoggedIn) {
    return (
      <section className="w-full py-12 md:py-24" id="dashboard-preview">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Track Your Legal Journey</h2>
              <p className="max-w-[700px] text-muted-foreground md:text-xl">
                Sign up to access your personalized dashboard and keep track of your legal documents and progress.
              </p>
              <div className="flex justify-center pt-4">
                <Button onClick={() => setIsLoggedIn(true)}>Preview Dashboard</Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="w-full py-12 md:py-24" id="dashboard-preview">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Your Legal Dashboard</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Keep track of your legal documents, templates, and progress all in one place.
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-5xl">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="progress">Progress</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Legal Health Score</CardTitle>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-4 w-4 text-muted-foreground"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                    </svg>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">75%</div>
                    <Progress value={75} className="h-2 mt-2" />
                    <p className="text-xs text-muted-foreground mt-2">+5% from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Documents Created</CardTitle>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">7</div>
                    <p className="text-xs text-muted-foreground mt-2">3 pending completion</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">AI Consultations</CardTitle>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-4 w-4 text-muted-foreground"
                    >
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                    </svg>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">12</div>
                    <p className="text-xs text-muted-foreground mt-2">Last consultation: 2 days ago</p>
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Your recent interactions with Legal Saarthi</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          icon: FileText,
                          title: "Rental Agreement Template",
                          time: "2 days ago",
                          status: "Downloaded",
                        },
                        {
                          icon: CheckCircle,
                          title: "Consumer Complaint",
                          time: "1 week ago",
                          status: "Completed",
                        },
                        {
                          icon: AlertCircle,
                          title: "RTI Application",
                          time: "2 weeks ago",
                          status: "In Progress",
                        },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center">
                          <div className="mr-4 flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
                            <item.icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 space-y-1">
                            <p className="text-sm font-medium leading-none">{item.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {item.time} • {item.status}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle>Upcoming Deadlines</CardTitle>
                    <CardDescription>Important dates for your legal matters</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          icon: Clock,
                          title: "Respond to Landlord Notice",
                          date: "May 15, 2025",
                          urgency: "High",
                        },
                        {
                          icon: Clock,
                          title: "Submit Consumer Court Documents",
                          date: "May 22, 2025",
                          urgency: "Medium",
                        },
                        {
                          icon: Clock,
                          title: "Review Employment Contract",
                          date: "June 1, 2025",
                          urgency: "Low",
                        },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center">
                          <div className="mr-4 flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
                            <item.icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 space-y-1">
                            <p className="text-sm font-medium leading-none">{item.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {item.date} • Priority: {item.urgency}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="documents" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Documents</CardTitle>
                  <CardDescription>Manage all your legal documents and templates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-md border">
                      <div className="p-4">
                        <h3 className="font-medium">Document Library</h3>
                        <p className="text-sm text-muted-foreground">All your saved and created documents</p>
                      </div>
                      <div className="border-t">
                        {[
                          {
                            title: "Rental Agreement",
                            type: "Template",
                            date: "Apr 10, 2025",
                            status: "Complete",
                          },
                          {
                            title: "Consumer Complaint",
                            type: "Form",
                            date: "Apr 5, 2025",
                            status: "In Progress",
                          },
                          {
                            title: "RTI Application",
                            type: "Form",
                            date: "Mar 28, 2025",
                            status: "Complete",
                          },
                          {
                            title: "Employment Contract",
                            type: "Template",
                            date: "Mar 15, 2025",
                            status: "Complete",
                          },
                        ].map((doc, index) => (
                          <div key={index} className="flex items-center justify-between p-4 border-b last:border-b-0">
                            <div>
                              <div className="font-medium">{doc.title}</div>
                              <div className="text-sm text-muted-foreground">
                                {doc.type} • Created: {doc.date}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span
                                className={`text-xs px-2 py-1 rounded-full ${
                                  doc.status === "Complete"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-yellow-100 text-yellow-800"
                                }`}
                              >
                                {doc.status}
                              </span>
                              <Button variant="ghost" size="sm">
                                View
                              </Button>
                              <Button variant="ghost" size="sm">
                                Download
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="progress" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Legal Journey</CardTitle>
                  <CardDescription>Track your progress across different legal areas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        area: "Tenant Rights",
                        progress: 80,
                        completed: 4,
                        total: 5,
                      },
                      {
                        area: "Consumer Protection",
                        progress: 60,
                        completed: 3,
                        total: 5,
                      },
                      {
                        area: "Employment Laws",
                        progress: 40,
                        completed: 2,
                        total: 5,
                      },
                      {
                        area: "Filing RTIs",
                        progress: 20,
                        completed: 1,
                        total: 5,
                      },
                    ].map((area, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{area.area}</div>
                          <div className="text-sm text-muted-foreground">
                            {area.completed}/{area.total} completed
                          </div>
                        </div>
                        <Progress value={area.progress} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  )
}
