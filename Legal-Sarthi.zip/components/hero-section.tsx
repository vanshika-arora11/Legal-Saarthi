import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, MessageSquare } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Simplifying Legal Knowledge for Everyone
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Get step-by-step guidance for real-life legal problems in language you can understand.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Type your legal question..." className="pl-8 w-full" />
              </div>
              <Button className="gap-1">
                <MessageSquare className="h-4 w-4" />
                Ask AI
              </Button>
              <Button variant="outline">Explore Legal Help</Button>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[600px] aspect-square">
              <img
                src="/placeholder.svg?height=600&width=600"
                alt="Legal assistance illustration"
                className="rounded-lg object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
