"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Sidebar as SidebarComponent,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import {
  BookOpen,
  FileText,
  Home,
  MessageSquare,
  Settings,
  Shield,
  User,
  Users,
  FileQuestion,
  Building,
  ShoppingCart,
  FileSearch,
  HelpCircle,
  Info,
} from "lucide-react"

export default function Sidebar() {
  const pathname = usePathname()

  const mainNavItems = [
    { name: "Home", href: "/", icon: Home },
    { name: "Legal Topics", href: "#legal-topics", icon: BookOpen },
    { name: "Templates", href: "#templates", icon: FileText },
    { name: "Ask AI", href: "#ask-ai", icon: MessageSquare },
  ]

  const legalTopics = [
    { name: "Tenant Rights", href: "#tenant-rights", icon: Building },
    { name: "Employment Laws", href: "#employment-laws", icon: Users },
    { name: "Cybercrime", href: "#cybercrime", icon: Shield },
    { name: "Women's Safety", href: "#womens-safety", icon: User },
    { name: "Consumer Protection", href: "#consumer-protection", icon: ShoppingCart },
    { name: "Filing FIRs / RTIs", href: "#filing-firs-rtis", icon: FileSearch },
  ]

  const helpItems = [
    { name: "FAQs", href: "#faqs", icon: FileQuestion },
    { name: "Help Center", href: "#help-center", icon: HelpCircle },
    { name: "About Us", href: "/about", icon: Info },
    { name: "Settings", href: "/settings", icon: Settings },
  ]

  return (
    <SidebarComponent>
      <SidebarHeader className="border-b">
        <div className="flex items-center p-4">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-6 w-6 mr-2"
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
          </svg>
          <span className="font-serif text-xl font-semibold">Legal Saarthi</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton asChild isActive={pathname === item.href} tooltip={item.name}>
                    <Link href={item.href}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Legal Topics</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {legalTopics.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton asChild tooltip={item.name}>
                    <Link href={item.href}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Help & Settings</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {helpItems.map((item) => (
                <SidebarMenuItem key={item.name}>
                  <SidebarMenuButton asChild isActive={pathname === item.href} tooltip={item.name}>
                    <Link href={item.href}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <div className="flex flex-col space-y-2">
          <p className="text-xs text-muted-foreground">© 2025 Legal Saarthi. All rights reserved.</p>
        </div>
      </SidebarFooter>
      <SidebarRail />
    </SidebarComponent>
  )
}
