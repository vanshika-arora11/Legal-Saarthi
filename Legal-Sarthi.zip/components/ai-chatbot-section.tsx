"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Mic, Plus, Search, Send } from "lucide-react"

export default function AIChatbotSection() {
  const [messages, setMessages] = useState([
    {
      role: "system",
      content: "Hello! I'm your Legal Saarthi AI assistant. How can I help you with your legal questions today?",
    },
  ])
  const [input, setInput] = useState("")

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { role: "user", content: input }])
      // Simulate AI response
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            role: "system",
            content:
              "I'm here to help with your legal questions. For this demo, I'm providing a placeholder response. In the actual implementation, I would connect to the Gemini API to generate relevant legal information based on your query.",
          },
        ])
      }, 1000)
      setInput("")
    }
  }

  const exampleQuestions = [
    "What should I do if my landlord refuses to return my security deposit?",
    "How do I file an RTI application?",
    "What are my rights if I'm facing workplace harassment?",
    "How can I file a consumer complaint against a company?",
  ]

  return (
    <section className="w-full py-12 md:py-24 bg-muted/50" id="ask-ai">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Ask Our AI Legal Assistant</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Get instant answers to your legal questions 24/7 from our AI-powered chatbot.
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-3xl">
          <Card className="border-2 border-muted">
            <CardHeader className="bg-background border-b">
              <CardTitle className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4 text-primary"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  </svg>
                </div>
                Legal Saarthi AI Assistant
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[400px] overflow-y-auto p-4 space-y-4">
                {messages.map((message, index) => (
                  <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] rounded-lg px-4 py-2 ${
                        message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4 p-4 pt-0">
              {messages.length === 1 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 w-full">
                  {exampleQuestions.map((question, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="justify-start h-auto py-2 px-3 text-sm"
                      onClick={() => {
                        setInput(question)
                      }}
                    >
                      <Search className="h-3.5 w-3.5 mr-2 flex-shrink-0" />
                      <span className="text-left line-clamp-1">{question}</span>
                    </Button>
                  ))}
                </div>
              )}
              <div className="flex w-full items-center space-x-2">
                <Button variant="outline" size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
                <Input
                  placeholder="Type your legal question..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSend()
                    }
                  }}
                  className="flex-1"
                />
                <Button variant="outline" size="icon">
                  <Mic className="h-4 w-4" />
                </Button>
                <Button size="icon" onClick={handleSend}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </section>
  )
}
