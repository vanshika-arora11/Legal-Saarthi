import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Globe, Volume2, ZoomIn } from "lucide-react"

export default function LanguageSection() {
  const languages = [
    { name: "English", code: "en" },
    { name: "हिन्दी (Hindi)", code: "hi" },
    { name: "தமிழ் (Tamil)", code: "ta" },
    { name: "తెలుగు (Telugu)", code: "te" },
    { name: "বাংলা (Bengali)", code: "bn" },
    { name: "मराठी (Marathi)", code: "mr" },
  ]

  return (
    <section className="w-full py-12 md:py-24 bg-muted/50" id="language-section">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Breaking Language Barriers</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Access legal information in your preferred language and format.
            </p>
          </div>
        </div>

        <div className="mx-auto max-w-5xl">
          <div className="grid gap-6 md:gri-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Globe className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Multiple Languages</CardTitle>
                <CardDescription>Choose from a variety of Indian languages to access our content.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {languages.map((language) => (
                    <Button key={language.code} variant="outline" className="justify-start">
                      {language.name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <ZoomIn className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Accessibility Options</CardTitle>
                <CardDescription>Customize your reading experience for better accessibility.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Text Size</h3>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        A-
                      </Button>
                      <Button variant="outline" size="sm">
                        A
                      </Button>
                      <Button variant="outline" size="sm">
                        A+
                      </Button>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-2">Contrast</h3>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        Normal
                      </Button>
                      <Button variant="outline" size="sm">
                        High
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Volume2 className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Voice Assistance</CardTitle>
                <CardDescription>Use voice commands and text-to-speech features for easier navigation.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button className="w-full">
                    <Volume2 className="mr-2 h-4 w-4" />
                    Enable Text-to-Speech
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    Our voice assistance feature helps those with reading difficulties or visual impairments access
                    legal information more easily.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
