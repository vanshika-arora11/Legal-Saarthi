import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, MessageSquare, FileText, Globe } from "lucide-react"

export default function FeaturesSection() {
  const features = [
    {
      icon: Brain,
      title: "Simple Legal Guidance",
      description: "Complex legal concepts explained in simple, everyday language that anyone can understand.",
    },
    {
      icon: MessageSquare,
      title: "AI Chatbot Help 24/7",
      description: "Get instant answers to your legal questions anytime with our AI-powered assistant.",
    },
    {
      icon: FileText,
      title: "Downloadable Templates",
      description: "Access ready-to-use templates for RTIs, complaints, notices, and other legal documents.",
    },
    {
      icon: Globe,
      title: "Multi-language Support",
      description: "Content available in multiple Indian languages to break down language barriers.",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 bg-muted/50" id="features">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How Legal Saarthi Helps You</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl">
              Our platform is designed to make legal knowledge accessible and actionable for everyone.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4 mt-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-2 border-muted">
              <CardHeader className="pb-2">
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
